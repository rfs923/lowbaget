import asyncio
from scanners import subdomain_enum, vuln_scan, auto_update

async def main():
    print("[*] Starting real-time vulnerability scanner...")
    subdomains = await subdomain_enum.run()
    scan_results = await vuln_scan.run(subdomains)
    await auto_update.evaluate_and_update(scan_results)

if __name__ == "__main__":
    asyncio.run(main())
