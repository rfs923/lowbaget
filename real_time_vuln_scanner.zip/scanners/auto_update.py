import asyncio
import subprocess

async def evaluate_and_update(scan_results):
    print("[*] Evaluating scan results...")
    if not scan_results:
        print("[!] No vulnerabilities found, checking for updates...")
        await update_tools()
    else:
        print("[*] Vulnerabilities found, skipping update.")
    
async def update_tools():
    print("[*] Updating scanning tools...")
    subprocess.run(["nuclei", "-ut"], check=True)
    subprocess.run(["subfinder", "-update"], check=True)
    print("[*] Tools updated successfully.")
