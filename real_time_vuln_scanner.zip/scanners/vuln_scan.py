import asyncio
import subprocess

async def run(subdomains):
    print("[*] Running vulnerability scanning...")
    results = []
    for subdomain in subdomains:
        cmd = ["nuclei", "-u", subdomain, "-silent"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        results.append((subdomain, result.stdout.strip()))
    return results
