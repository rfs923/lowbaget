import asyncio
import subprocess

async def run():
    print("[*] Running subdomain enumeration...")
    cmd = ["subfinder", "-d", "example.com", "-silent"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    subdomains = result.stdout.strip().split("\n")
    print(f"[*] Found {len(subdomains)} subdomains.")
    return subdomains
